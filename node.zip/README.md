# XBitCloud Static Hosting — Setup Guide

## How It Works

```
┌─────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  Admin Panel │────>│  XBitCloud API   │────>│  VPS (Caddy)    │
│  (Add Node)  │     │  (SSH + SFTP)    │     │  Serves sites   │
└─────────────┘     └──────────────────┘     └─────────────────┘
                           │
                    ┌──────┴──────┐
                    │  User Panel │
                    │  - Create   │
                    │  - Files    │
                    │  - Domain   │
                    └─────────────┘
```

**The XBitCloud server connects to your VPS via SSH.** It runs shell scripts to create/delete sites, and uses SFTP for file management. Users never touch the VPS directly.

---

## Step-by-Step Setup

### Step 1: Get a VPS

Any Ubuntu/Debian VPS with:
- Root SSH access (password or key)
- Port 22 (SSH), 80 (HTTP), 443 (HTTPS), 8080 (Stats API) open
- A public IP address
- Minimum 1GB RAM, 20GB disk recommended

### Step 2: Set up DNS

Point a wildcard subdomain to your VPS IP:

```
*.sites.xbitcode.com  →  A record  →  YOUR_VPS_IP
sites.xbitcode.com    →  A record  →  YOUR_VPS_IP
```

This lets Caddy auto-provision SSL for `anything.sites.xbitcode.com`.

### Step 3: Upload & run install script on VPS

SSH into your VPS manually (one-time only):

```bash
ssh root@YOUR_VPS_IP
```

Upload the install script and stats API files:

```bash
mkdir -p /home/hosting/api
# Upload these files to the VPS:
#   hosting/install_host.sh      → /home/hosting/install_host.sh
#   hosting/api/server.py        → /home/hosting/api/server.py
#   hosting/api/requirements.txt → /home/hosting/api/requirements.txt
```

You can use `scp` from your local machine:

```bash
scp hosting/install_host.sh root@YOUR_VPS_IP:/home/hosting/
scp hosting/api/server.py root@YOUR_VPS_IP:/home/hosting/api/
scp hosting/api/requirements.txt root@YOUR_VPS_IP:/home/hosting/api/
```

Then run the install script with your API key:

```bash
chmod +x /home/hosting/install_host.sh
bash /home/hosting/install_host.sh "1234567865432134565er432"  # Use a secure random key here
```

This installs:
- **Caddy** web server (auto-SSL, serves all hosted sites)
- **Flask stats API** on port 8080 (disk usage, file counts)
- **Cron job** to collect stats every 5 minutes
- Directory structure at `/home/hosting/sites/`
- `hosting` system group for user isolation

### Step 4: Add the node in Admin Panel

Go to **Admin Panel → Host Manager → Add Node** and fill in:

| Field | Value | Example |
|-------|-------|---------|
| Label | A friendly name | `VPS-1 Mumbai` |
| IP Address | VPS public IP | `103.x.x.x` |
| SSH Port | Usually 22 | `22` |
| SSH User | `root` | `root` |
| SSH Password | Your root password | `•••••` |
| Default Domain | Wildcard domain | `sites.xbitcode.com` |
| API Key | Same key from install script | `1234567865432134565er432` |
| API Port | Stats API port | `8080` |
| Max Sites | Site limit for this VPS | `100` |

Click **Add Node**. The node should show as **Active**.

### Step 5: Done! Users can now create sites

Users go to `/hosting` → enter a subdomain → click **Create Free Website**.

The system automatically:
1. Picks a node with available capacity
2. SSHs into the VPS
3. Runs `create_site.sh` (creates Linux user, web root, Caddy config)
4. Site goes live at `subdomain.sites.xbitcode.com`
5. User can upload/edit files via the built-in File Manager

---

## What's Automatic vs Manual

| Action | How |
|--------|-----|
| **Prepare VPS** (install Caddy, scripts) | Manual — run `install_host.sh` once per VPS |
| **Add node to platform** | Manual — Admin Panel → Host Manager |
| **Create user site** | Automatic — user clicks "Create" |
| **Delete user site** | Automatic — user or admin clicks "Delete" |
| **File upload/edit/delete** | Automatic — via File Manager UI |
| **SSL certificates** | Automatic — Caddy handles it |
| **Custom domains** | Semi-auto — user adds domain, must point DNS manually |
| **Storage stats** | Automatic — synced via stats API every 5 min |

---

## Adding More VPS Nodes

To scale, repeat Steps 1-4 with a new VPS. The system auto-distributes new sites across nodes with available capacity.

---

## File Structure on VPS

```
/home/hosting/
├── sites/
│   └── h_mysite/           ← one per user
│       ├── www/             ← web root (public files)
│       │   └── index.html   ← default landing page
│       └── etc/             ← internal config
├── sites.d/
│   └── h_mysite.caddy       ← Caddy config per site
├── api/
│   └── server.py            ← stats API
├── install_host.sh
├── create_site.sh
├── delete_site.sh
└── add_domain.sh
```

---

## Shell Scripts Reference

| Script | Purpose | Called By |
|--------|---------|-----------|
| `install_host.sh <api_key>` | One-time VPS setup | You (manual) |
| `create_site.sh <username> <subdomain> <domain> [storage_mb]` | Provision a site | API (automatic) |
| `delete_site.sh <username>` | Remove a site | API (automatic) |
| `add_domain.sh <username> <domain>` | Add custom domain | API (automatic) |

---

## Troubleshooting

**Site not loading?**
- Check DNS: `dig subdomain.sites.xbitcode.com` should return VPS IP
- Check Caddy: `systemctl status caddy-hosting`
- Check site config exists: `ls /home/hosting/sites.d/`

**Stats not updating?**
- Check stats API: `curl -H "X-API-Key: YOUR_KEY" http://VPS_IP:8080/health`
- Check cron: `crontab -l` should show stats collection job
- Check stats API service: `systemctl status hosting-api`

**File upload failing?**
- Check SSH connectivity from your XBitCloud server to the VPS
- Check disk space: `df -h`
- Check user quota: `quota -u h_username`
