"""
XBitCloud Static Hosting — Read-Only Stats API
Runs on port 8080. Authenticated via X-API-Key header.
No POST, no writes, no command execution.
"""

import os
import json
import time
from pathlib import Path
from flask import Flask, jsonify, request, abort

app = Flask(__name__)

API_KEY = os.environ.get("API_KEY", "changeme-set-this-in-env")
HOSTING_ROOT = os.environ.get("HOSTING_ROOT", "/home/hosting")
SITES_DIR = os.path.join(HOSTING_ROOT, "sites")
API_PORT = int(os.environ.get("API_PORT", 8080))

START_TIME = time.time()


def require_auth():
    """Verify X-API-Key header."""
    key = request.headers.get("X-API-Key", "")
    if key != API_KEY:
        abort(403, description="Invalid API key")


@app.before_request
def auth_check():
    require_auth()


@app.route("/health")
def health():
    return jsonify({
        "status": "ok",
        "uptime": int(time.time() - START_TIME),
        "sites_dir": SITES_DIR
    })


@app.route("/sites")
def list_sites():
    """List all sites with their stats."""
    sites = []
    sites_path = Path(SITES_DIR)
    if not sites_path.exists():
        return jsonify(sites)

    for user_dir in sorted(sites_path.iterdir()):
        if not user_dir.is_dir():
            continue
        username = user_dir.name
        stats = _read_stats(username)
        sites.append({
            "username": username,
            **stats
        })

    return jsonify(sites)


@app.route("/stats/<username>")
def site_stats(username):
    """Get stats for a specific site."""
    # Sanitize username — only allow alphanumeric + hyphen + underscore
    if not _is_safe_username(username):
        abort(400, description="Invalid username")

    user_dir = Path(SITES_DIR) / username
    if not user_dir.exists():
        abort(404, description="Site not found")

    stats = _read_stats(username)
    return jsonify(stats)


@app.route("/quota/<username>")
def site_quota(username):
    """Get disk quota info for a site."""
    if not _is_safe_username(username):
        abort(400, description="Invalid username")

    user_dir = Path(SITES_DIR) / username
    if not user_dir.exists():
        abort(404, description="Site not found")

    www_dir = user_dir / "www"
    disk_used = _get_dir_size(www_dir)

    return jsonify({
        "username": username,
        "disk_used": disk_used,
    })


def _read_stats(username):
    """Read stats.json for a user, with fallback to live calculation."""
    stats_file = Path(SITES_DIR) / username / "etc" / "stats.json"

    if stats_file.exists():
        try:
            with open(stats_file, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass

    # Fallback: calculate live
    www_dir = Path(SITES_DIR) / username / "www"
    return {
        "disk_used": _get_dir_size(www_dir),
        "files": _count_files(www_dir),
        "updated": None
    }


def _get_dir_size(path):
    """Get total size of directory in bytes."""
    total = 0
    p = Path(path)
    if p.exists():
        for f in p.rglob("*"):
            if f.is_file():
                total += f.stat().st_size
    return total


def _count_files(path):
    """Count total files in directory."""
    p = Path(path)
    if p.exists():
        return sum(1 for f in p.rglob("*") if f.is_file())
    return 0


def _is_safe_username(username):
    """Only allow safe characters in username."""
    import re
    return bool(re.match(r'^[a-zA-Z0-9_-]+$', username))


if __name__ == "__main__":
    print(f"XBitCloud Stats API starting on port {API_PORT}")
    app.run(host="0.0.0.0", port=API_PORT, debug=False)
