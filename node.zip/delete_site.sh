#!/bin/bash
# ============================================================
# XBitCloud Static Hosting — Delete Site
# Usage: sudo bash delete_site.sh <username>
# Example: sudo bash delete_site.sh alice
# ============================================================

set -euo pipefail

USERNAME="${1:-}"

if [ -z "$USERNAME" ]; then
    echo "Usage: $0 <username>"
    exit 1
fi

HOSTING_ROOT="/home/hosting"
SITES_DIR="$HOSTING_ROOT/sites"
SITES_D="$HOSTING_ROOT/sites.d"
USER_DIR="$SITES_DIR/$USERNAME"
CADDY_SITE_CONF="$SITES_D/${USERNAME}.caddy"

echo "=== Deleting hosting site: $USERNAME ==="

# ---- 1. Remove Caddy config ----
if [ -f "$CADDY_SITE_CONF" ]; then
    rm -f "$CADDY_SITE_CONF"
    echo "Removed Caddy config."
fi

# ---- 2. Reload Caddy ----
if systemctl is-active --quiet caddy-hosting; then
    caddy reload --config "$HOSTING_ROOT/Caddyfile" --adapter caddyfile 2>/dev/null && \
        echo "Caddy reloaded." || \
        echo "WARNING: Caddy reload failed."
fi

# ---- 3. Remove site directory ----
if [ -d "$USER_DIR" ]; then
    rm -rf "$USER_DIR"
    echo "Removed site directory: $USER_DIR"
fi

# ---- 4. Remove Linux user ----
if id "$USERNAME" &>/dev/null; then
    userdel "$USERNAME" 2>/dev/null || true
    echo "Removed system user: $USERNAME"
fi

echo ""
echo "=== Site deleted: $USERNAME ==="
