#!/bin/bash
# ============================================================
# XBitCloud Static Hosting — VPS Bootstrap Script
# Run once on a fresh Ubuntu 24.04 VPS to set up everything
# Usage: sudo bash install_host.sh <api_key>
# ============================================================

set -euo pipefail

# ---- Arguments ----
API_KEY="${1:-changeme-set-this-in-env}"

# ---- Configuration ----
HOSTING_ROOT="/home/hosting"
SITES_DIR="$HOSTING_ROOT/sites"
CADDY_CONF="$HOSTING_ROOT/Caddyfile"
SITES_D="$HOSTING_ROOT/sites.d"
API_DIR="$HOSTING_ROOT/api"
API_PORT=8080
STATS_CRON_INTERVAL=5  # minutes

echo "=== XBitCloud Hosting VPS Setup ==="
echo ""

# ---- 1. System packages ----
echo "[1/8] Updating system and installing dependencies..."
apt-get update -qq
apt-get install -y -qq curl gnupg2 python3 python3-pip python3-venv quota quotatool ufw unzip jq

# ---- 2. Install Caddy ----
echo "[2/8] Installing Caddy..."
if ! command -v caddy &>/dev/null; then
    curl -fsSL https://caddyserver.com/api/download?os=linux\&arch=amd64 -o /usr/bin/caddy
    chmod +x /usr/bin/caddy
    caddy version
    echo "Caddy installed."
else
    echo "Caddy already installed: $(caddy version)"
fi

# ---- 3. Create directory structure ----
echo "[3/8] Creating directory structure..."
mkdir -p "$SITES_DIR" "$SITES_D" "$API_DIR"

# ---- 4. Create Caddy system user and group ----
echo "[4/8] Setting up Caddy user/group..."
if ! id caddy &>/dev/null; then
    groupadd --system caddy
    useradd --system --gid caddy --create-home --home-dir /var/lib/caddy --shell /usr/sbin/nologin caddy
fi

# Add caddy to a shared hosting group
groupadd -f hosting
usermod -aG hosting caddy

# ---- 5. Write main Caddyfile ----
echo "[5/8] Writing Caddyfile..."
cat > "$CADDY_CONF" << 'CADDYEOF'
# XBitCloud Static Hosting — Main Caddyfile
# Each site is defined in sites.d/*.caddy

{
    admin off
    email ssl@xbitcloud.com
}

import /home/hosting/sites.d/*.caddy
CADDYEOF

# ---- 6. Create Caddy systemd service ----
echo "[6/8] Creating Caddy systemd service..."
cat > /etc/systemd/system/caddy-hosting.service << EOF
[Unit]
Description=XBitCloud Hosting Caddy Server
After=network.target network-online.target
Requires=network-online.target

[Service]
Type=notify
User=caddy
Group=hosting
ExecStart=/usr/bin/caddy run --config $CADDY_CONF --adapter caddyfile
ExecReload=/usr/bin/caddy reload --config $CADDY_CONF --adapter caddyfile
TimeoutStopSec=5s
LimitNOFILE=1048576
LimitNPROC=512
AmbientCapabilities=CAP_NET_BIND_SERVICE
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable caddy-hosting
systemctl start caddy-hosting || echo "Caddy will start once sites are added."

# ---- 7. Set up stats API ----
echo "[7/8] Setting up stats API..."
python3 -m venv "$API_DIR/venv"
"$API_DIR/venv/bin/pip" install -q flask

# Copy the API server (should already be placed at hosting/api/server.py)
if [ ! -f "$API_DIR/server.py" ]; then
    echo "WARNING: $API_DIR/server.py not found. Copy it manually."
fi

# Create systemd service for stats API
cat > /etc/systemd/system/hosting-api.service << EOF
[Unit]
Description=XBitCloud Hosting Stats API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$API_DIR
ExecStart=$API_DIR/venv/bin/python $API_DIR/server.py
Restart=always
RestartSec=5
Environment=API_PORT=$API_PORT
Environment=HOSTING_ROOT=$HOSTING_ROOT
Environment=API_KEY=$API_KEY

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable hosting-api
systemctl start hosting-api || echo "Stats API will start once server.py is deployed."

# ---- 8. Set up stats cron ----
echo "[8/8] Setting up stats cron job..."
CRON_SCRIPT="$HOSTING_ROOT/update_stats.sh"
cat > "$CRON_SCRIPT" << 'CRONEOF'
#!/bin/bash
# Collect per-site stats and write to stats.json
SITES_DIR="/home/hosting/sites"

for dir in "$SITES_DIR"/*/; do
    [ -d "$dir" ] || continue
    username=$(basename "$dir")
    www_dir="$dir/www"
    etc_dir="$dir/etc"
    stats_file="$etc_dir/stats.json"

    mkdir -p "$etc_dir"

    if [ -d "$www_dir" ]; then
        disk_used=$(du -sb "$www_dir" 2>/dev/null | cut -f1)
        file_count=$(find "$www_dir" -type f 2>/dev/null | wc -l)
    else
        disk_used=0
        file_count=0
    fi

    cat > "$stats_file" << JSONEOF
{"disk_used":$disk_used,"files":$file_count,"updated":"$(date -Is)"}
JSONEOF
done
CRONEOF
chmod +x "$CRON_SCRIPT"

# Add cron entry
CRON_LINE="*/$STATS_CRON_INTERVAL * * * * $CRON_SCRIPT >/dev/null 2>&1"
(crontab -l 2>/dev/null | grep -v update_stats.sh; echo "$CRON_LINE") | crontab -

# ---- Firewall ----
echo ""
echo "=== Firewall Setup ==="
echo "Run these manually (adjust BACKEND_IP to your xbitcloud server IP):"
echo "  ufw allow 80/tcp"
echo "  ufw allow 443/tcp"
echo "  ufw allow 22/tcp"
echo "  ufw allow from BACKEND_IP to any port $API_PORT"
echo "  ufw enable"

# ---- Set permissions ----
chown -R root:hosting "$HOSTING_ROOT"
chmod 755 "$HOSTING_ROOT"
chmod 755 "$SITES_DIR"

echo ""
echo "=== Setup Complete ==="
echo "Hosting root:  $HOSTING_ROOT"
echo "Sites dir:     $SITES_DIR"
echo "Caddy config:  $CADDY_CONF"
echo "Stats API:     http://0.0.0.0:$API_PORT"
echo ""
echo "Next steps:"
echo "  1. Point *.yourdomain.com DNS to this VPS IP"
echo "  2. Add this node in XBitCloud Admin Panel → Host Manager"
sudo bash -c 'rm -f /etc/ssh/sshd_config.d/*.conf 2>/dev/null; sed -i "s/^#\?PermitRootLogin.*/PermitRootLogin yes/" /etc/ssh/sshd_config; sed -i "s/^#\?PasswordAuthentication.*/PasswordAuthentication yes/" /etc/ssh/sshd_config; systemctl restart sshd;systemctl restart ssh'
