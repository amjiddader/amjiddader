#!/bin/bash
# ============================================================
# XBitCloud Static Hosting — Add Custom Domain
# Usage: sudo bash add_domain.sh <username> <custom_domain>
# Example: sudo bash add_domain.sh alice www.mysite.com
# ============================================================

set -euo pipefail

USERNAME="${1:-}"
CUSTOM_DOMAIN="${2:-}"

if [ -z "$USERNAME" ] || [ -z "$CUSTOM_DOMAIN" ]; then
    echo "Usage: $0 <username> <custom_domain>"
    exit 1
fi

HOSTING_ROOT="/home/hosting"
SITES_DIR="$HOSTING_ROOT/sites"
SITES_D="$HOSTING_ROOT/sites.d"
WWW_DIR="$SITES_DIR/$USERNAME/www"
CADDY_SITE_CONF="$SITES_D/${USERNAME}.caddy"

if [ ! -d "$WWW_DIR" ]; then
    echo "ERROR: Site not found for user $USERNAME"
    exit 1
fi

if [ ! -f "$CADDY_SITE_CONF" ]; then
    echo "ERROR: Caddy config not found for user $USERNAME"
    exit 1
fi

# Read domain line (line 2 of caddy config, e.g. "mysite.example.com {")
EXISTING_LINE=$(sed -n '2p' "$CADDY_SITE_CONF")
EXISTING_DOMAINS=$(echo "$EXISTING_LINE" | sed 's/ {$//')

# Check if custom domain is already present
if echo "$EXISTING_DOMAINS" | grep -qF "$CUSTOM_DOMAIN"; then
    echo "Domain $CUSTOM_DOMAIN already configured."
    exit 0
fi

# Add the custom domain (Caddy uses space-separated domains)
NEW_DOMAINS="$EXISTING_DOMAINS $CUSTOM_DOMAIN"
sed -i "2s|.*|${NEW_DOMAINS} {|" "$CADDY_SITE_CONF"

# Update comment
sed -i "1s|.*|# Site: $USERNAME ($NEW_DOMAINS)|" "$CADDY_SITE_CONF"

# Reload Caddy
if systemctl is-active --quiet caddy-hosting; then
    caddy reload --config "$HOSTING_ROOT/Caddyfile" --adapter caddyfile 2>/dev/null && \
        echo "Caddy reloaded. SSL will be provisioned automatically." || \
        echo "WARNING: Caddy reload failed. Check config."
fi

echo "=== Custom domain added ==="
echo "  Domain: $CUSTOM_DOMAIN"
echo "  User must point DNS A record to this VPS IP."
