#!/bin/bash
# ============================================================
# XBitCloud Static Hosting — Create Site
# Usage: sudo bash create_site.sh <username> <subdomain> <domain> [storage_mb]
# Example: sudo bash create_site.sh alice mysite sites.xbitcode.com 50
# ============================================================

set -euo pipefail

USERNAME="${1:-}"
SUBDOMAIN="${2:-}"
DOMAIN="${3:-}"
STORAGE_MB="${4:-50}"

if [ -z "$USERNAME" ] || [ -z "$SUBDOMAIN" ] || [ -z "$DOMAIN" ]; then
    echo "Usage: $0 <username> <subdomain> <domain> [storage_mb]"
    echo "Example: $0 alice mysite sites.xbitcode.com 50"
    exit 1
fi

HOSTING_ROOT="/home/hosting"
SITES_DIR="$HOSTING_ROOT/sites"
SITES_D="$HOSTING_ROOT/sites.d"
USER_DIR="$SITES_DIR/$USERNAME"
WWW_DIR="$USER_DIR/www"
ETC_DIR="$USER_DIR/etc"
FULL_DOMAIN="${SUBDOMAIN}.${DOMAIN}"

echo "=== Creating hosting site ==="
echo "  User:      $USERNAME"
echo "  Domain:    $FULL_DOMAIN"
echo "  Storage:   ${STORAGE_MB}MB"

# ---- 1. Create Linux user (no login, no shell) ----
if id "$USERNAME" &>/dev/null; then
    echo "User $USERNAME already exists, skipping user creation."
else
    useradd \
        --system \
        --no-create-home \
        --shell /usr/sbin/nologin \
        --gid hosting \
        "$USERNAME"
    # Lock the password so nobody can login
    passwd -l "$USERNAME" >/dev/null 2>&1
    echo "Created system user: $USERNAME"
fi

# ---- 2. Create directory structure ----
mkdir -p "$WWW_DIR" "$ETC_DIR"

# ---- 3. Create default index.html ----
cat > "$WWW_DIR/index.html" << 'HTMLEOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome | Powered by XBitCloud</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0a0e14;
            color: #e6edf3;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        .card {
            text-align: center;
            padding: 3rem 2rem;
            border: 1px solid #30363d;
            border-radius: 16px;
            background: #0d1117;
            max-width: 480px;
        }
        .logo {
            font-size: 2rem;
            font-weight: 800;
            color: #00ffcc;
            margin-bottom: 1rem;
        }
        h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
        p { color: #8b949e; line-height: 1.6; margin-bottom: 1.5rem; }
        a {
            display: inline-block;
            padding: 0.6rem 1.5rem;
            border-radius: 8px;
            background: #00ffcc;
            color: #0a0e14;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }
        a:hover { opacity: 0.9; }
        .footer { margin-top: 2rem; font-size: 0.75rem; color: #6e7681; }
        .footer a { background: none; color: #00ffcc; padding: 0; font-weight: 400; }
    </style>
</head>
<body>
    <div class="card">
        <div class="logo">xbitcloud</div>
        <h1>Website Created!</h1>
        <p>Your site is live and ready. Upload your files to get started.</p>
        <a href="https://cloud.xbitcode.com" target="_blank">Go to Dashboard</a>
        <div class="footer">
            Powered by <a href="https://cloud.xbitcode.com" target="_blank">XBitCloud</a> Static Hosting
        </div>
    </div>
</body>
</html>
HTMLEOF

# ---- 4. Create initial stats ----
cat > "$ETC_DIR/stats.json" << JSONEOF
{"disk_used":0,"files":1,"updated":"$(date -Is)"}
JSONEOF

# ---- 5. Set permissions ----
# User owns their www directory, caddy (in hosting group) can read it
chown -R "$USERNAME:hosting" "$USER_DIR"
chmod 750 "$USER_DIR"
chmod 750 "$WWW_DIR"
chmod 750 "$ETC_DIR"
# Files inside www should be readable by caddy
find "$WWW_DIR" -type f -exec chmod 644 {} \;
find "$WWW_DIR" -type d -exec chmod 755 {} \;

# ---- 6. Set disk quota ----
STORAGE_KB=$((STORAGE_MB * 1024))
STORAGE_BLOCKS=$((STORAGE_KB))
# Soft limit = hard limit (no grace period)
if command -v setquota &>/dev/null; then
    setquota -u "$USERNAME" "$STORAGE_BLOCKS" "$STORAGE_BLOCKS" 0 0 / 2>/dev/null || \
        echo "WARNING: Disk quotas not enabled on filesystem. Run: quotaon -avug"
fi

# ---- 7. Create Caddy config for this site ----
CADDY_SITE_CONF="$SITES_D/${USERNAME}.caddy"
cat > "$CADDY_SITE_CONF" << CADDYEOF
# Site: $USERNAME ($FULL_DOMAIN)
$FULL_DOMAIN {
    root * $WWW_DIR
    file_server
    encode gzip

    # Custom error pages
    handle_errors {
        @404 expression {err.status_code} == 404
        handle @404 {
            try_files /404.html
            file_server
        }
    }

    # Security headers
    header {
        X-Content-Type-Options "nosniff"
        X-Frame-Options "DENY"
        Referrer-Policy "strict-origin-when-cross-origin"
        -Server
    }

    # Cache static assets
    @static path *.css *.js *.png *.jpg *.jpeg *.gif *.svg *.ico *.woff *.woff2 *.ttf *.eot *.webp *.avif
    header @static Cache-Control "public, max-age=31536000, immutable"

    # Block dangerous file types from being served
    @blocked path *.php *.py *.rb *.sh *.cgi *.pl *.exe *.bat *.env *.htaccess
    respond @blocked 403
}
CADDYEOF

# ---- 8. Reload Caddy ----
if systemctl is-active --quiet caddy-hosting; then
    caddy reload --config "$HOSTING_ROOT/Caddyfile" --adapter caddyfile 2>/dev/null && \
        echo "Caddy reloaded." || \
        echo "WARNING: Caddy reload failed. Check config with: caddy validate --config $HOSTING_ROOT/Caddyfile"
else
    systemctl start caddy-hosting 2>/dev/null || echo "Caddy not running. Start with: systemctl start caddy-hosting"
fi

echo ""
echo "=== Site created ==="
echo "  URL:       https://$FULL_DOMAIN"
echo "  Web root:  $WWW_DIR"
echo "  Caddy cfg: $CADDY_SITE_CONF"
echo "  Quota:     ${STORAGE_MB}MB"
